import React, { useState } from 'react';
import { Search, Plus, TreePine, Home, Users, Shield, AlertTriangle, FileText } from 'lucide-react';
import { usePersonData } from './hooks/usePersonData';
import { Dashboard } from './components/Dashboard';
import { SearchForm } from './components/SearchForm';
import { PersonList } from './components/PersonList';
import { TreeVisualization } from './components/TreeVisualization';
import { AddPersonForm } from './components/AddPersonForm';
import { PersonCard } from './components/PersonCard';

type ViewType = 'dashboard' | 'search' | 'tree' | 'add';

function App() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [showAddForm, setShowAddForm] = useState(false);
  const {
    filteredPersons,
    personTree,
    searchCriteria,
    setSearchCriteria,
    addPerson,
    updatePerson,
    searchMatches
  } = usePersonData();

  const handleSearch = (criteria: any) => {
    setSearchCriteria(criteria);
    setCurrentView('search');
  };

  const handleAddPerson = (personData: any) => {
    addPerson(personData);
    setShowAddForm(false);
    setCurrentView('search');
  };

  const handleStatusChange = (personId: string, newStatus: Person['status']) => {
    updatePerson(personId, { status: newStatus });
  };

  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'search', label: 'Search Database', icon: Search },
    { id: 'tree', label: 'Data Analysis', icon: TreePine },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Professional Header */}
      <header className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="bg-gradient-to-br from-blue-600 to-blue-800 p-3 rounded-xl shadow-lg">
                  <Shield className="h-8 w-8 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 bg-red-500 rounded-full p-1">
                  <AlertTriangle className="h-3 w-3 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-800 to-blue-600 bg-clip-text text-transparent">
                  Person Identifier Using Hashing and Tree
                </h1>
                <p className="text-sm text-gray-600 font-medium">Advanced Search & Analysis System</p>
              </div>
            </div>
            
            {/* Professional Stats Bar */}
            <div className="hidden lg:flex items-center space-x-6 bg-gray-50 rounded-lg px-6 py-3">
              <div className="text-center">
                <div className="text-lg font-bold text-blue-600">24/7</div>
                <div className="text-xs text-gray-600">Active</div>
              </div>
              <div className="w-px h-8 bg-gray-300"></div>
              <div className="text-center">
                <div className="text-lg font-bold text-green-600">98.2%</div>
                <div className="text-xs text-gray-600">Success Rate</div>
              </div>
              <div className="w-px h-8 bg-gray-300"></div>
              <div className="text-center">
                <div className="text-lg font-bold text-purple-600">AI</div>
                <div className="text-xs text-gray-600">Enhanced</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Action Bar with Missing Report Button */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span>System Online</span>
              </div>
              <div className="text-sm text-gray-500">
                Last Updated: {new Date().toLocaleString()}
              </div>
            </div>
            
            {/* Prominent Missing Report Button */}
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setCurrentView('search')}
                className="flex items-center space-x-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-lg hover:bg-blue-200 transition-all duration-200 border border-blue-200"
              >
                <Search className="h-4 w-4" />
                <span>Quick Search</span>
              </button>
              
              <button
                onClick={() => setShowAddForm(true)}
                className="flex items-center space-x-2 bg-gradient-to-r from-red-600 to-red-700 text-white px-6 py-2.5 rounded-lg hover:from-red-700 hover:to-red-800 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 font-semibold"
              >
                <FileText className="h-5 w-5" />
                <span>File Missing Report</span>
                <div className="bg-white bg-opacity-20 rounded-full px-2 py-0.5 text-xs">
                  URGENT
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id as ViewType)}
                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-all duration-200 ${
                  currentView === item.id
                    ? 'border-blue-600 text-blue-700 bg-blue-50 rounded-t-lg px-4'
                    : 'border-transparent text-gray-600 hover:text-gray-800 hover:border-gray-300'
                }`}
              >
                <item.icon className="h-4 w-4" />
                <span>{item.label}</span>
                {currentView === item.id && (
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                )}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content with Enhanced Background */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showAddForm && (
          <div className="mb-8">
            <div className="bg-gradient-to-r from-red-50 to-orange-50 border-l-4 border-red-500 rounded-lg p-4 mb-4">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <h3 className="font-semibold text-red-800">Emergency Missing Person Report</h3>
              </div>
              <p className="text-red-700 text-sm mt-1">
                Please provide as much detail as possible. This information will be immediately distributed to law enforcement agencies.
              </p>
            </div>
            <AddPersonForm
              onAdd={handleAddPerson}
              onCancel={() => setShowAddForm(false)}
            />
          </div>
        )}

        {currentView === 'dashboard' && <Dashboard />}
        
        {currentView === 'search' && (
          <div className="space-y-6">
            <SearchForm
              onSearch={handleSearch}
              onClear={() => setSearchCriteria({})}
            />
            <PersonList 
              persons={filteredPersons} 
              onStatusChange={handleStatusChange}
            />
          </div>
        )}

        {currentView === 'tree' && (
          <TreeVisualization tree={personTree} />
        )}
      </main>

      {/* Professional Footer */}
      <footer className="bg-gray-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Shield className="h-6 w-6 text-blue-400" />
                <span className="font-bold text-lg">NMPD</span>
              </div>
              <p className="text-gray-400 text-sm">
                Advanced missing person identification system serving law enforcement agencies nationwide.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Emergency Contacts</h4>
              <div className="space-y-2 text-sm text-gray-400">
                <p>24/7 Hotline: 1-800-MISSING</p>
                <p>Law Enforcement: 911</p>
                <p>FBI: 1-800-CALL-FBI</p>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Resources</h4>
              <div className="space-y-2 text-sm text-gray-400">
                <p>Search Guidelines</p>
                <p>Report Forms</p>
                <p>Family Support</p>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3">System Status</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-400">All Systems Operational</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-gray-400">AI Processing Active</span>
                </div>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-6 text-center text-sm text-gray-400">
            <p>&copy; 2024 National Missing Person Database. All rights reserved. | Secure • Confidential • Professional</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;