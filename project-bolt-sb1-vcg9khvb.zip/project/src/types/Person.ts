export interface Person {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  height: number; // in cm
  weight: number; // in kg
  eyeColor: string;
  hairColor: string;
  description: string;
  lastSeenLocation: string;
  lastSeenDate: string;
  reportedDate: string;
  status: 'missing' | 'found' | 'investigating';
  contactInfo: {
    reporterName: string;
    reporterPhone: string;
    reporterEmail: string;
  };
  photos?: string[];
  distinguishingFeatures: string[];
  hash: string;
}

export interface PersonNode {
  person: Person;
  children: PersonNode[];
  parent?: PersonNode;
  similarity?: number;
}

export interface SearchCriteria {
  name?: string;
  ageRange?: [number, number];
  gender?: string;
  location?: string;
  eyeColor?: string;
  hairColor?: string;
  status?: string;
}