import { Person, PersonNode } from '../types/Person';
import { calculateSimilarity } from './hashUtils';

// Build tree structure based on person similarities
export const buildPersonTree = (persons: Person[]): PersonNode[] => {
  if (persons.length === 0) return [];

  const nodes: PersonNode[] = persons.map(person => ({
    person,
    children: []
  }));

  // Group similar persons as children
  const roots: PersonNode[] = [];
  const processed = new Set<string>();

  nodes.forEach(node => {
    if (processed.has(node.person.id)) return;

    const similarNodes = nodes.filter(n => 
      n.person.id !== node.person.id && 
      !processed.has(n.person.id) &&
      calculateSimilarity(node.person, n.person) > 0.5
    );

    if (similarNodes.length > 0) {
      similarNodes.forEach(similar => {
        similar.parent = node;
        similar.similarity = calculateSimilarity(node.person, similar.person);
        node.children.push(similar);
        processed.add(similar.person.id);
      });
    }

    roots.push(node);
    processed.add(node.person.id);
  });

  return roots;
};

// Find potential matches in the tree
export const findMatches = (
  target: Person, 
  tree: PersonNode[], 
  threshold: number = 0.3
): PersonNode[] => {
  const matches: PersonNode[] = [];

  const traverse = (node: PersonNode) => {
    const similarity = calculateSimilarity(target, node.person);
    if (similarity >= threshold) {
      matches.push({
        ...node,
        similarity
      });
    }
    
    node.children.forEach(child => traverse(child));
  };

  tree.forEach(root => traverse(root));
  
  return matches.sort((a, b) => (b.similarity || 0) - (a.similarity || 0));
};

// Get tree statistics
export const getTreeStats = (tree: PersonNode[]) => {
  let totalNodes = 0;
  let maxDepth = 0;
  let leafNodes = 0;

  const traverse = (node: PersonNode, depth: number) => {
    totalNodes++;
    maxDepth = Math.max(maxDepth, depth);
    
    if (node.children.length === 0) {
      leafNodes++;
    }
    
    node.children.forEach(child => traverse(child, depth + 1));
  };

  tree.forEach(root => traverse(root, 1));
  
  return {
    totalNodes,
    maxDepth,
    leafNodes,
    rootNodes: tree.length
  };
};

// Calculate similarity between two persons based on physical characteristics
export const calculateSimilarity = (person1: Person, person2: Person): number => {
  let score = 0;
  const weights = {
    name: 0.25,
    age: 0.15,
    gender: 0.10,
    eyeColor: 0.15,
    hairColor: 0.15,
    height: 0.10,
    weight: 0.10
  };

  // Name similarity (basic)
  const name1 = person1.name.toLowerCase();
  const name2 = person2.name.toLowerCase();
  if (name1.includes(name2) || name2.includes(name1)) {
    score += weights.name;
  } else {
    // Check for partial name matches
    const words1 = name1.split(' ');
    const words2 = name2.split(' ');
    let nameMatches = 0;
    words1.forEach(word1 => {
      words2.forEach(word2 => {
        if (word1 === word2 && word1.length > 2) {
          nameMatches++;
        }
      });
    });
    if (nameMatches > 0) {
      score += (weights.name * nameMatches) / Math.max(words1.length, words2.length);
    }
  }

  // Age similarity (graduated scoring)
  const ageDiff = Math.abs(person1.age - person2.age);
  if (ageDiff === 0) {
    score += weights.age;
  } else if (ageDiff <= 2) {
    score += weights.age * 0.8;
  } else if (ageDiff <= 5) {
    score += weights.age * 0.5;
  } else if (ageDiff <= 10) {
    score += weights.age * 0.2;
  }

  // Gender match
  if (person1.gender === person2.gender) {
    score += weights.gender;
  }

  // Eye color match
  if (person1.eyeColor.toLowerCase() === person2.eyeColor.toLowerCase()) {
    score += weights.eyeColor;
  }

  // Hair color match
  if (person1.hairColor.toLowerCase() === person2.hairColor.toLowerCase()) {
    score += weights.hairColor;
  }

  // Height similarity (graduated scoring)
  const heightDiff = Math.abs(person1.height - person2.height);
  if (heightDiff <= 5) {
    score += weights.height;
  } else if (heightDiff <= 10) {
    score += weights.height * 0.7;
  } else if (heightDiff <= 20) {
    score += weights.height * 0.3;
  }

  // Weight similarity (graduated scoring)
  const weightDiff = Math.abs(person1.weight - person2.weight);
  if (weightDiff <= 5) {
    score += weights.weight;
  } else if (weightDiff <= 10) {
    score += weights.weight * 0.7;
  } else if (weightDiff <= 20) {
    score += weights.weight * 0.3;
  }

  return score;
};