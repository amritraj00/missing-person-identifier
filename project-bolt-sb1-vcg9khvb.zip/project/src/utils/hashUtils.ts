import { Person } from '../types/Person';

// Simple hash function for person identification
export const hashPerson = (person: Partial<Person>): string => {
  // Enhanced hash function with better distribution
  const key = `${person.name || ''}_${person.age || 0}_${person.gender || ''}_${person.eyeColor || ''}_${person.hairColor || ''}_${person.height || 0}_${person.weight || 0}`;
  
  // Simple hash algorithm for better distribution
  let hash = 0;
  for (let i = 0; i < key.length; i++) {
    const char = key.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  
  // Convert to positive hex string
  const hexHash = Math.abs(hash).toString(16).toUpperCase();
  return `MP${hexHash.padStart(8, '0').substring(0, 8)}`;
};

// Calculate similarity between two persons based on physical characteristics
export const calculateSimilarity = (person1: Person, person2: Person): number => {
  let score = 0;
  let factors = 0;

  // Name similarity (basic)
  if (person1.name.toLowerCase().includes(person2.name.toLowerCase()) || 
      person2.name.toLowerCase().includes(person1.name.toLowerCase())) {
    score += 0.3;
  }
  factors++;

  // Age similarity (within 2 years)
  if (Math.abs(person1.age - person2.age) <= 2) {
    score += 0.2;
  }
  factors++;

  // Gender match
  if (person1.gender === person2.gender) {
    score += 0.15;
  }
  factors++;

  // Eye color match
  if (person1.eyeColor.toLowerCase() === person2.eyeColor.toLowerCase()) {
    score += 0.15;
  }
  factors++;

  // Hair color match
  if (person1.hairColor.toLowerCase() === person2.hairColor.toLowerCase()) {
    score += 0.15;
  }
  factors++;

  // Height similarity (within 10cm)
  if (Math.abs(person1.height - person2.height) <= 10) {
    score += 0.05;
  }
  factors++;

  return score;
};

// Create hash index for fast searching
export const createHashIndex = (persons: Person[]): Map<string, Person[]> => {
  const index = new Map<string, Person[]>();
  
  persons.forEach(person => {
    const hash = person.hash;
    if (!index.has(hash)) {
      index.set(hash, []);
    }
    index.get(hash)!.push(person);
  });
  
  return index;
};

// Quick search using hash index
export const quickSearch = (
  query: Partial<Person>, 
  hashIndex: Map<string, Person[]>
): Person[] => {
  const queryHash = hashPerson(query);
  return hashIndex.get(queryHash) || [];
};