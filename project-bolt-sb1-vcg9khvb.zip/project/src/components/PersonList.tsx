import React from 'react';
import { Person } from '../types/Person';
import { PersonCard } from './PersonCard';

interface PersonListProps {
  persons: Person[];
  onPersonClick?: (person: Person) => void;
  onStatusChange?: (personId: string, newStatus: Person['status']) => void;
  title?: string;
}

export const PersonList: React.FC<PersonListProps> = ({ persons, onPersonClick, onStatusChange, title = "Missing Persons Database" }) => {
  if (persons.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">{title}</h2>
        <div className="text-center py-12 text-gray-500">
          <div className="bg-gray-100 rounded-full p-6 w-24 h-24 mx-auto mb-4 flex items-center justify-center">
            <Users className="h-12 w-12 text-gray-400" />
          </div>
          <p className="text-lg font-medium">No persons found matching the criteria</p>
          <p className="text-sm mt-2">Try adjusting your search parameters or add a new missing person report</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
          <p className="text-sm text-gray-600 mt-1">Advanced tree-based search results with hash indexing</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-blue-600">{persons.length}</div>
          <div className="text-sm text-gray-600">{persons.length === 1 ? 'Record' : 'Records'}</div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {persons.map((person) => (
          <PersonCard
            key={person.id}
            person={person}
            onClick={() => onPersonClick?.(person)}
            onStatusChange={onStatusChange}
          />
        ))}
      </div>
    </div>
  );
};