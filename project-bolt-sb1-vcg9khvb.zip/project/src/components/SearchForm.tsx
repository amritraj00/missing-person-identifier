import React, { useState } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { SearchCriteria } from '../types/Person';

interface SearchFormProps {
  onSearch: (criteria: SearchCriteria) => void;
  onClear: () => void;
}

export const SearchForm: React.FC<SearchFormProps> = ({ onSearch, onClear }) => {
  const [criteria, setCriteria] = useState<SearchCriteria>({});
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(criteria);
  };

  const handleClear = () => {
    setCriteria({});
    onClear();
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-900">Search Missing Persons</h2>
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-800"
        >
          <Filter className="h-4 w-4" />
          <span>{showAdvanced ? 'Hide' : 'Show'} Advanced</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Name
            </label>
            <input
              type="text"
              value={criteria.name || ''}
              onChange={(e) => setCriteria(prev => ({ ...prev, name: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter name..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Location
            </label>
            <input
              type="text"
              value={criteria.location || ''}
              onChange={(e) => setCriteria(prev => ({ ...prev, location: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Last seen location..."
            />
          </div>
        </div>

        {showAdvanced && (
          <div className="space-y-4 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Gender
                </label>
                <select
                  value={criteria.gender || ''}
                  onChange={(e) => setCriteria(prev => ({ ...prev, gender: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Any</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Eye Color
                </label>
                <input
                  type="text"
                  value={criteria.eyeColor || ''}
                  onChange={(e) => setCriteria(prev => ({ ...prev, eyeColor: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Eye color..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Hair Color
                </label>
                <input
                  type="text"
                  value={criteria.hairColor || ''}
                  onChange={(e) => setCriteria(prev => ({ ...prev, hairColor: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Hair color..."
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Age Range
                </label>
                <div className="flex space-x-2">
                  <input
                    type="number"
                    value={criteria.ageRange?.[0] || ''}
                    onChange={(e) => setCriteria(prev => ({ 
                      ...prev, 
                      ageRange: [parseInt(e.target.value) || 0, prev.ageRange?.[1] || 100]
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Min age"
                  />
                  <input
                    type="number"
                    value={criteria.ageRange?.[1] || ''}
                    onChange={(e) => setCriteria(prev => ({ 
                      ...prev, 
                      ageRange: [prev.ageRange?.[0] || 0, parseInt(e.target.value) || 100]
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Max age"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  value={criteria.status || ''}
                  onChange={(e) => setCriteria(prev => ({ ...prev, status: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Any Status</option>
                  <option value="missing">Missing</option>
                  <option value="found">Found</option>
                  <option value="investigating">Investigating</option>
                </select>
              </div>
            </div>
          </div>
        )}

        <div className="flex space-x-4">
          <button
            type="submit"
            className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
          >
            <Search className="h-4 w-4" />
            <span>Search</span>
          </button>
          <button
            type="button"
            onClick={handleClear}
            className="flex items-center space-x-2 bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300 transition-colors"
          >
            <X className="h-4 w-4" />
            <span>Clear</span>
          </button>
        </div>
      </form>
    </div>
  );
};