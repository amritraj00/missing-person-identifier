import React from 'react';
import { Person } from '../types/Person';
import { User, MapPin, Calendar, Phone, Mail, Hash, TreePine, CheckCircle, AlertTriangle, Search } from 'lucide-react';

interface PersonCardProps {
  person: Person;
  onClick?: () => void;
  showSimilarity?: number;
  onStatusChange?: (personId: string, newStatus: Person['status']) => void;
}

export const PersonCard: React.FC<PersonCardProps> = ({ person, onClick, showSimilarity, onStatusChange }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'missing':
        return 'bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg';
      case 'found':
        return 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg';
      case 'investigating':
        return 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-white shadow-lg';
      default:
        return 'bg-gradient-to-r from-gray-500 to-gray-600 text-white shadow-lg';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'missing':
        return AlertTriangle;
      case 'found':
        return CheckCircle;
      case 'investigating':
        return Search;
      default:
        return User;
    }
  };

  const handleStatusChange = (newStatus: Person['status']) => {
    if (onStatusChange) {
      onStatusChange(person.id, newStatus);
    }
  };

  const StatusIcon = getStatusIcon(person.status);

  return (
    <div
      className="bg-white rounded-xl shadow-lg p-6 hover:shadow-2xl transition-all duration-300 cursor-pointer border border-gray-200 hover:border-blue-300 transform hover:-translate-y-1"
      onClick={onClick}
    >
      {/* Header with Hash Display */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2 bg-gray-50 rounded-lg px-3 py-1">
          <Hash className="h-3 w-3 text-gray-500" />
          <span className="text-xs font-mono text-gray-600">{person.hash}</span>
        </div>
        <div className="flex items-center space-x-1 bg-blue-50 rounded-lg px-2 py-1">
          <TreePine className="h-3 w-3 text-blue-600" />
          <span className="text-xs text-blue-600 font-medium">Tree Node</span>
        </div>
      </div>

      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-3 rounded-xl shadow-lg">
            <User className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900 text-lg">{person.name}</h3>
            <p className="text-sm text-gray-600">{person.age} years old • {person.gender}</p>
          </div>
        </div>
        {showSimilarity && (
          <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg">
            {Math.round(showSimilarity * 100)}% match
          </div>
        )}
      </div>

      {/* Enhanced Status Section */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold text-gray-700 uppercase tracking-wide">Current Status</span>
          <span className={`px-4 py-2 rounded-full text-sm font-bold flex items-center space-x-2 ${getStatusColor(person.status)}`}>
            <StatusIcon className="h-4 w-4" />
            <span>{person.status.toUpperCase()}</span>
          </span>
        </div>
        
        {onStatusChange && (
          <div className="bg-gray-50 rounded-xl p-4">
            <p className="text-xs font-medium text-gray-600 mb-3 text-center">Update Status</p>
            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleStatusChange('missing');
                }}
                className={`group relative px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-300 flex flex-col items-center space-y-2 ${
                  person.status === 'missing'
                    ? 'bg-gradient-to-br from-red-500 to-red-600 text-white shadow-lg transform scale-105'
                    : 'bg-white text-red-600 hover:bg-red-50 border-2 border-red-200 hover:border-red-300 hover:shadow-md hover:scale-105'
                }`}
              >
                <AlertTriangle className="h-5 w-5" />
                <span>Missing</span>
                {person.status === 'missing' && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-400 rounded-full animate-pulse"></div>
                )}
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleStatusChange('investigating');
                }}
                className={`group relative px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-300 flex flex-col items-center space-y-2 ${
                  person.status === 'investigating'
                    ? 'bg-gradient-to-br from-yellow-500 to-yellow-600 text-white shadow-lg transform scale-105'
                    : 'bg-white text-yellow-600 hover:bg-yellow-50 border-2 border-yellow-200 hover:border-yellow-300 hover:shadow-md hover:scale-105'
                }`}
              >
                <Search className="h-5 w-5" />
                <span>Investigating</span>
                {person.status === 'investigating' && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
                )}
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleStatusChange('found');
                }}
                className={`group relative px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-300 flex flex-col items-center space-y-2 ${
                  person.status === 'found'
                    ? 'bg-gradient-to-br from-green-500 to-green-600 text-white shadow-lg transform scale-105'
                    : 'bg-white text-green-600 hover:bg-green-50 border-2 border-green-200 hover:border-green-300 hover:shadow-md hover:scale-105'
                }`}
              >
                <CheckCircle className="h-5 w-5" />
                <span>Found</span>
                {person.status === 'found' && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="space-y-3">
        <div className="flex items-center space-x-3 text-sm text-gray-700 bg-gray-50 rounded-lg p-3">
          <MapPin className="h-4 w-4 text-blue-500" />
          <span className="font-medium">Last seen:</span>
          <span>{person.lastSeenLocation}</span>
        </div>
        <div className="flex items-center space-x-3 text-sm text-gray-700 bg-gray-50 rounded-lg p-3">
          <Calendar className="h-4 w-4 text-blue-500" />
          <span className="font-medium">Date:</span>
          <span>{new Date(person.lastSeenDate).toLocaleDateString()}</span>
        </div>
      </div>

      <div className="mt-5 pt-4 border-t border-gray-200">
        <div className="grid grid-cols-3 gap-3 text-xs">
          <div className="text-center bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl py-3 px-2">
            <div className="font-bold text-blue-900 text-lg">{person.height}cm</div>
            <div className="text-blue-600 font-medium">Height</div>
          </div>
          <div className="text-center bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl py-3 px-2">
            <div className="font-bold text-purple-900 text-lg">{person.eyeColor}</div>
            <div className="text-purple-600 font-medium">Eyes</div>
          </div>
          <div className="text-center bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl py-3 px-2">
            <div className="font-bold text-orange-900 text-lg">{person.hairColor}</div>
            <div className="text-orange-600 font-medium">Hair</div>
          </div>
        </div>
      </div>

      <div className="mt-4">
        <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-4">
          <p className="text-xs font-semibold text-gray-600 mb-2 uppercase tracking-wide">Description</p>
          <p className="text-sm text-gray-800 leading-relaxed">{person.description}</p>
        </div>
      </div>

      <div className="mt-5 pt-4 border-t border-gray-200">
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4">
          <p className="text-xs font-bold text-blue-800 mb-3 uppercase tracking-wide flex items-center">
            <Phone className="h-3 w-3 mr-1" />
            Emergency Contact
          </p>
          <p className="text-sm text-blue-900 font-bold mb-2">{person.contactInfo.reporterName}</p>
          <div className="flex flex-col space-y-2">
            <div className="flex items-center space-x-2">
              <Phone className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-blue-700 font-medium">{person.contactInfo.reporterPhone}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-blue-700 font-medium">{person.contactInfo.reporterEmail}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};