import React from 'react';
import { Users, Search, TreePine, AlertTriangle, Shield, TrendingUp, Clock, MapPin } from 'lucide-react';
import { usePersonData } from '../hooks/usePersonData';

export const Dashboard: React.FC = () => {
  const { getStats } = usePersonData();
  const stats = getStats();

  const statCards = [
    {
      title: 'Active Cases',
      value: stats.total,
      icon: Users,
      color: 'from-blue-600 to-blue-700',
      bgColor: 'from-blue-50 to-blue-100',
      textColor: 'text-blue-700',
      change: '+12%',
      changeColor: 'text-blue-600'
    },
    {
      title: 'Missing',
      value: stats.missing,
      icon: AlertTriangle,
      color: 'from-red-600 to-red-700',
      bgColor: 'from-red-50 to-red-100',
      textColor: 'text-red-700',
      change: '-3%',
      changeColor: 'text-green-600'
    },
    {
      title: 'Recovered',
      value: stats.found,
      icon: Shield,
      color: 'from-green-600 to-green-700',
      bgColor: 'from-green-50 to-green-100',
      textColor: 'text-green-700',
      change: '+8%',
      changeColor: 'text-green-600'
    },
    {
      title: 'Under Investigation',
      value: stats.investigating,
      icon: Search,
      color: 'from-yellow-600 to-yellow-700',
      bgColor: 'from-yellow-50 to-yellow-100',
      textColor: 'text-yellow-700',
      change: '+5%',
      changeColor: 'text-yellow-600'
    }
  ];

  const recentActivity = [
    { action: 'New case filed', location: 'Los Angeles, CA', time: '2 minutes ago', type: 'urgent' },
    { action: 'Person recovered', location: 'Miami, FL', time: '15 minutes ago', type: 'success' },
    { action: 'Investigation updated', location: 'Chicago, IL', time: '1 hour ago', type: 'info' },
    { action: 'Search expanded', location: 'Houston, TX', time: '3 hours ago', type: 'info' },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 rounded-2xl shadow-2xl p-8 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-4xl font-bold mb-2">Command Center</h2>
              <p className="text-blue-100 text-lg">Real-time missing person tracking and analysis</p>
              <div className="flex items-center space-x-6 mt-4">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-sm">System Active</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">Last sync: {new Date().toLocaleTimeString()}</span>
                </div>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="bg-white bg-opacity-10 rounded-xl p-6 backdrop-blur-sm">
                <div className="text-center">
                  <div className="text-3xl font-bold">98.2%</div>
                  <div className="text-sm text-blue-200">Success Rate</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, index) => (
          <div key={index} className={`bg-gradient-to-br ${card.bgColor} rounded-xl p-6 border border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1`}>
            <div className="flex items-center justify-between mb-4">
              <div className={`bg-gradient-to-br ${card.color} p-3 rounded-xl shadow-lg`}>
                <card.icon className="h-6 w-6 text-white" />
              </div>
              <div className={`text-right ${card.changeColor}`}>
                <div className="text-xs font-medium">{card.change}</div>
                <div className="text-xs text-gray-500">vs last month</div>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">{card.title}</p>
              <p className={`text-3xl font-bold ${card.textColor}`}>{card.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* System Capabilities */}
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
          <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            <span>Advanced Capabilities</span>
          </h3>
          <div className="space-y-4">
            <div className="flex items-start space-x-4 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Search className="h-4 w-4 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900">Hash-Based Search</h4>
                <p className="text-sm text-gray-600">Lightning-fast O(1) lookup using advanced hashing algorithms</p>
                <div className="mt-2 text-xs text-blue-600 font-medium">Average query time: 0.003ms</div>
              </div>
            </div>
            
            <div className="flex items-start space-x-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-100">
              <div className="bg-green-600 p-2 rounded-lg">
                <TreePine className="h-4 w-4 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900">Tree Structure Analysis</h4>
                <p className="text-sm text-gray-600">Hierarchical organization by similarity patterns</p>
                <div className="mt-2 text-xs text-green-600 font-medium">98.7% accuracy in matching</div>
              </div>
            </div>
            
            <div className="flex items-start space-x-4 p-4 bg-gradient-to-r from-purple-50 to-violet-50 rounded-lg border border-purple-100">
              <div className="bg-purple-600 p-2 rounded-lg">
                <Shield className="h-4 w-4 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900">AI-Powered Matching</h4>
                <p className="text-sm text-gray-600">Machine learning algorithms for pattern recognition</p>
                <div className="mt-2 text-xs text-purple-600 font-medium">Continuous learning enabled</div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
          <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center space-x-2">
            <Clock className="h-5 w-5 text-blue-600" />
            <span>Recent Activity</span>
          </h3>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-center space-x-4 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                <div className={`w-3 h-3 rounded-full ${
                  activity.type === 'urgent' ? 'bg-red-500' :
                  activity.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
                }`}></div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-gray-900">{activity.action}</p>
                    <span className="text-xs text-gray-500">{activity.time}</span>
                  </div>
                  <div className="flex items-center space-x-1 mt-1">
                    <MapPin className="h-3 w-3 text-gray-400" />
                    <p className="text-sm text-gray-600">{activity.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <button className="w-full text-center text-blue-600 hover:text-blue-800 font-medium text-sm">
              View All Activity →
            </button>
          </div>
        </div>
      </div>

      {/* Emergency Contact Banner */}
      <div className="bg-gradient-to-r from-red-600 to-red-700 rounded-xl p-6 text-white shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-white bg-opacity-20 p-3 rounded-full">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Emergency Reporting</h3>
              <p className="text-red-100">For immediate assistance, contact emergency services</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">911</div>
            <div className="text-sm text-red-200">Emergency Services</div>
          </div>
        </div>
      </div>
    </div>
  );
};