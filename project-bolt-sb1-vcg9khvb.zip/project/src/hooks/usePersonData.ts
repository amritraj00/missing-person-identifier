import { useState, useEffect, useMemo } from 'react';
import { Person, PersonNode, SearchCriteria } from '../types/Person';
import { hashPerson, createHashIndex, quickSearch } from '../utils/hashUtils';
import { buildPersonTree, findMatches } from '../utils/treeUtils';

// Mock data for demonstration
const mockPersons: Person[] = [
  {
    id: '1',
    name: 'John Smith',
    age: 28,
    gender: 'male',
    height: 175,
    weight: 70,
    eyeColor: 'Brown',
    hairColor: 'Black',
    description: 'Average build, no visible scars',
    lastSeenLocation: 'Downtown Mall',
    lastSeenDate: '2024-01-15',
    reportedDate: '2024-01-16',
    status: 'missing',
    contactInfo: {
      reporterName: 'Jane Smith',
      reporterPhone: '+1-555-0123',
      reporterEmail: 'jane.smith@email.com'
    },
    distinguishingFeatures: ['Scar on left hand', 'Tattoo on right arm'],
    hash: ''
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    age: 34,
    gender: 'female',
    height: 165,
    weight: 60,
    eyeColor: 'Blue',
    hairColor: 'Blonde',
    description: 'Petite build, wears glasses',
    lastSeenLocation: 'Central Park',
    lastSeenDate: '2024-01-20',
    reportedDate: '2024-01-21',
    status: 'investigating',
    contactInfo: {
      reporterName: 'Mike Johnson',
      reporterPhone: '+1-555-0456',
      reporterEmail: 'mike.johnson@email.com'
    },
    distinguishingFeatures: ['Wears prescription glasses', 'Small birthmark on neck'],
    hash: ''
  },
  {
    id: '3',
    name: 'Michael Brown',
    age: 45,
    gender: 'male',
    height: 180,
    weight: 85,
    eyeColor: 'Green',
    hairColor: 'Brown',
    description: 'Tall, muscular build',
    lastSeenLocation: 'Office Building',
    lastSeenDate: '2024-01-25',
    reportedDate: '2024-01-26',
    status: 'found',
    contactInfo: {
      reporterName: 'Lisa Brown',
      reporterPhone: '+1-555-0789',
      reporterEmail: 'lisa.brown@email.com'
    },
    distinguishingFeatures: ['Beard', 'Wears wedding ring'],
    hash: ''
  }
];

// Generate hashes for mock data
mockPersons.forEach(person => {
  person.hash = hashPerson(person);
});

export const usePersonData = () => {
  const [persons, setPersons] = useState<Person[]>(mockPersons);
  const [searchCriteria, setSearchCriteria] = useState<SearchCriteria>({});
  const [loading, setLoading] = useState(false);

  // Create hash index for fast searching
  const hashIndex = useMemo(() => createHashIndex(persons), [persons]);

  // Build tree structure
  const personTree = useMemo(() => buildPersonTree(persons), [persons]);

  // Filter persons based on search criteria
  const filteredPersons = useMemo(() => {
    return persons.filter(person => {
      if (searchCriteria.name && !person.name.toLowerCase().includes(searchCriteria.name.toLowerCase())) {
        return false;
      }
      if (searchCriteria.ageRange && (person.age < searchCriteria.ageRange[0] || person.age > searchCriteria.ageRange[1])) {
        return false;
      }
      if (searchCriteria.gender && person.gender !== searchCriteria.gender) {
        return false;
      }
      if (searchCriteria.location && !person.lastSeenLocation.toLowerCase().includes(searchCriteria.location.toLowerCase())) {
        return false;
      }
      if (searchCriteria.eyeColor && person.eyeColor.toLowerCase() !== searchCriteria.eyeColor.toLowerCase()) {
        return false;
      }
      if (searchCriteria.hairColor && person.hairColor.toLowerCase() !== searchCriteria.hairColor.toLowerCase()) {
        return false;
      }
      if (searchCriteria.status && person.status !== searchCriteria.status) {
        return false;
      }
      return true;
    });
  }, [persons, searchCriteria]);

  // Add new person
  const addPerson = (personData: Omit<Person, 'id' | 'hash'>) => {
    const newPerson: Person = {
      ...personData,
      id: Date.now().toString(),
      hash: hashPerson(personData)
    };
    setPersons(prev => [...prev, newPerson]);
  };

  // Update person
  const updatePerson = (id: string, updates: Partial<Person>) => {
    setPersons(prev => 
      prev.map(person => 
        person.id === id 
          ? { ...person, ...updates, hash: hashPerson({ ...person, ...updates }) }
          : person
      )
    );
  };

  // Search for matches
  const searchMatches = (targetPerson: Person) => {
    return findMatches(targetPerson, personTree);
  };

  // Quick hash-based search
  const performQuickSearch = (query: Partial<Person>) => {
    return quickSearch(query, hashIndex);
  };

  // Get statistics
  const getStats = () => {
    const total = persons.length;
    const missing = persons.filter(p => p.status === 'missing').length;
    const found = persons.filter(p => p.status === 'found').length;
    const investigating = persons.filter(p => p.status === 'investigating').length;
    
    return { total, missing, found, investigating };
  };

  return {
    persons,
    filteredPersons,
    personTree,
    searchCriteria,
    loading,
    setSearchCriteria,
    addPerson,
    updatePerson,
    searchMatches,
    performQuickSearch,
    getStats
  };
};